/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package byui.cit260.clueTeam3.model;

/**
 *
 * @author Lauren
 */
public class Point { 
    private int row;
    private int column;
    

    //Point(int i, int i0) {
      //  throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
    
    public Point(int row,int column) {
        this.row = row;
        this.column = column;
        
    }
    
}
